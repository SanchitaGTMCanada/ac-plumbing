export const initialForm = {
  name: "",
  phone: "",
  email: "",
  service: "",
  date: "",
  time: "",
  address: "",
  notes: "",
};

export const timeSlots = [
  "08:00 AM",
  "09:00 AM",
  "10:00 AM",
  "11:00 AM",
  "12:00 PM",
  "01:00 PM",
  "02:00 PM",
  "03:00 PM",
  "04:00 PM",
  "05:00 PM",
  "06:00 PM",
];